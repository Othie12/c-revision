#include <stdio.h>
#include <string.h>

int main(void){

    printf("\t LIMKOKWING UNIVERSITY (LUCT)\n\n");
    printf("%-20s : %s\n", "Student Name", "Oketcho Silas");
    printf("%-20s : %s\n", "Course", "Bsc. Software Engineering with Multimedia");
    printf("%-20s : %s\n", "Student Number", "LUCT1100007");
    printf("%-20s : %s\n", "Semester", "6");
    printf("%-35s %-7s %s\n\n", "Module", "Mark", "Grade");

        printf("%-36s : %-7d %c\n", "Software Testing and Reliability", 98, 'A');
        printf("%-36s : %-7d %c\n", "Virtual reality", 56, 'B');
        printf("%-36s : %-7d %c\n", "Artificial intelligence", 76, 'C');
        printf("%-36s : %-7d %c\n", "Data analysis", 55, 'D');
        printf("%-36s : %-7d %c\n\n", "Introduction to web programming", 45, 'F');
}